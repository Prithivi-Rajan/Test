package com.bootup.ms.service;

import com.bootup.ms.entity.Item;

public interface ItemService {

	public Item save(Item item);
	
}
